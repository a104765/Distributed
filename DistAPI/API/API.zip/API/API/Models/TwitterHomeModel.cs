﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace API.Models
{
    public class TwitterHomeModel
    {
        public string created_at { get; set; }

        public string text { get; set; }
    }
}